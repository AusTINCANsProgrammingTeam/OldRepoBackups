
public class MatchAnalysis extends Analyzer {
	public MatchAnalysis(/*Match object*/){
		//ideally completes every task on instantiation.
	}
}
