
public class Test {
	public static void main(String args[]){
		//ilikehotgrills
		Team t = new Team();
		ConfigReader test = new ConfigReader();
		test.read(t);
		t.toString();
	}
}
