<<<<<<< HEAD
# RobotStatsPro
Pro FRC Statistics
WOW!
=======
# Scouting
warning: contains hax
still requires some sort of server infrastructure, but file --> team vals functionality working
>>>>>>> d47d0a47e8836dd971397659e38166a88bcefb34
