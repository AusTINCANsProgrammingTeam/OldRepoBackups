 public class vNotCalc {
    public static double angleR;
    public static double distanceX;
    public static double distanceY;
    public static double massWheel;
    public static double radiusWheel;
    public vNotCalc(double angleR, double distanceX, double distanceY)
    {
        this.angleR = angleR;
        this.distanceX = distanceX;
        this.distanceY = distanceY;
        this.massWheel = massWheel;
        this.radiusWheel = radiusWheel;
    }
    public static double distanceXtoNet(double distanceX) {
        //Actual distance(m)
        double actualdistanceX = Math.sqrt(distanceX * distanceX - distanceY * distanceY) + 0.2286;
        return actualdistanceX;
    }
    public static double getvNot(double angleR, double distanceY) {
           /* time= x/(cos(angle)Vnot), but in this case I multply by Vnot so you can get all the
        constant as one big number and deal with vNot later as a variable.
        t=x/(Vnotcos)
        y=Vnotsin*t+1/2*-9.8*t*t
        y=Vnotsin*x/vNotcos-4.9xx/(vNot*Vnot*cos*cos)
        y=tan*x-(4.9xx/cos/cos)/(vNot*vNot)
        y-tan*x=-(4.9xx/cos/cos)/(vNot*vNot) cross mutiply
        vNot*vNot= (4.9xx/cos/cos)/y-tan*x
        vNot(m/s)=Math.sqrt((4.9xx/cos/cos)/y-tan*x)
        */
        double time = vNotCalc.distanceXtoNet(distanceX) / Math.cos(angleR);
        double vNot = Math.sqrt(-4.9 * time * time / (distanceY - Math.tan(angleR) * distanceX));
        return vNot;
    }
    public static double getInertia(double massWheel, double radiusWheel) {
        //  I(kg m2 )= k m r2  k = inertial constant * mass of flywheel (kg, lbm) * radius (m, ft) * radius (m, ft)
        double inertia = massWheel * radiusWheel * 5;
        return inertia;
    }
    public double getEnergyNeeded(double radiusWheel, double massWheel) {
        // Ef = 1/2 I ω2     energy (Joules)=.5* inertia * velocityinRadians
        double vNotRadians = vNotCalc.getvNot(angleR, distanceY) / radiusWheel;
        double energyNedded = .5*vNotCalc.getInertia(massWheel, radiusWheel)*vNotRadians * vNotRadians;
        return energyNedded; 
    }
}
