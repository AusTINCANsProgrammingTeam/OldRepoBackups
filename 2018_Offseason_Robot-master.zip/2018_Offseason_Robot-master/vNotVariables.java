public class vNotVariables
{
    public static void main(String[] args)
    {
        double distanceX=Math.sqrt(68);
        double angleR= 45*Math.PI/180;
        double distanceY=2;
        double massWheel=100;
        double radiusWheel=5;
        double inertialConstant=10;
        vNotCalc vNot=new vNotCalc(  angleR,  distanceX,  distanceY);
        System.out.println("distanceX: "+vNot.distanceXtoNet(distanceX));
        System.out.println("vNot: "+vNot.getvNot(angleR, distanceY));
        System.out.println("Energy: "+vNot.getEnergyNeeded(radiusWheel, massWheel));
    }
}
