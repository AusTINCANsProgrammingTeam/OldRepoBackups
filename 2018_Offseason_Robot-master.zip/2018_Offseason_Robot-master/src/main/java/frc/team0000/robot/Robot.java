package frc.team0000.robot;

import com.ctre.phoenix.motorcontrol.can.TalonSRX;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.command.Scheduler;
import frc.team0000.robot.Subsystem.drive.DriveSubsystem;
import frc.team0000.robot.Subsystem.drive.GearMode;
import frc.team0000.robot.Subsystem.drive.TalonSRXGroup;
import edu.wpi.first.wpilibj.SpeedController;
import frc.team0000.robot.command.drive.DriveMode;
import frc.team0000.robot.command.drive.OperatorControl;
import frc.team0000.robot.command.drive.ToggleGearMode;

import java.util.logging.Logger;

import static com.sun.xml.internal.ws.spi.db.BindingContextFactory.LOGGER;

public class Robot extends TimedRobot {

    private static final Logger LOGGER = Logger.getLogger(Robot.class.getName());

    private static OperatorInterface operatorInterface;
    public static DriveSubsystem driveSubsystem;

    @Override
    public void robotInit() {
        //Initializse the drive subsystem
        driveSubsystem = new DriveSubsystem(
                new TalonSRXGroup(
                        new WPI_TalonSRX(RobotMap.LEFT_MOTOR_1),
                        new WPI_TalonSRX(RobotMap.LEFT_MOTOR_2),
                        new WPI_TalonSRX(RobotMap.LEFT_MOTOR_3)
                ),
                new TalonSRXGroup(
                        new WPI_TalonSRX(RobotMap.RIGHT_MOTOR_1),
                        new WPI_TalonSRX(RobotMap.RIGHT_MOTOR_2),
                        new WPI_TalonSRX(RobotMap.RIGHT_MOTOR_3)
                ),
                new DoubleSolenoid(RobotMap.PCM_ADRESS, RobotMap.GEARBOX_FORWARD_CHANNEL,
                        RobotMap.GEARBOX_REVERSE_CHANNEL)
        );
    }

    @Override
    public void disabledInit() { }

    @Override
    public void autonomousInit() { }

    @Override
    public void teleopInit() {
        LOGGER.info("Teleop Init");
        operatorInterface.bindButton("buttnA", OperatorInterface.ButtonMode.WHEN_PRESSED, new ToggleGearMode());
        Scheduler.getInstance().add(new OperatorControl(DriveMode.ARCADE));
    }


    @Override
    public void testInit() { }

    public static DriveSubsystem getDriveSubsystem(){
        if(driveSubsystem != null){
            return driveSubsystem;
        }
        throw new RuntimeException("Drive subsystem hasnot yet been initialized");
    }

    @Override
    public void disabledPeriodic() { }
    
    @Override
    public void autonomousPeriodic() { }


    @Override
    public void teleopPeriodic() {
        Scheduler.getInstance().run();
        GearMode gearMode = getDriveSubsystem().getGearMode();


    }


    @Override
    public void testPeriodic() {}

    public static OperatorInterface getOperatorInterface(){
        return operatorInterface;
    }


}