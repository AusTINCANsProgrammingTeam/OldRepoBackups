package frc.team0000.robot.command.drive;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.command.Command;
import frc.team0000.robot.Robot;
import frc.team0000.robot.Subsystem.drive.DriveSubsystem;
import frc.team0000.robot.OperatorInterface;

public class OperatorControl extends Command{

    private DriveMode driveMode;
    private DriveSubsystem driveSubsystem;
    private Joystick joystick;

    //initiates all operation controls

    public OperatorControl(DriveMode driveMode){
        this.driveMode = driveMode;
        this.driveSubsystem = Robot.getDriveSubsystem();
        this.joystick = Robot.getOperatorInterface().getJoystick();
    }
    public void execute(){
        switch(driveMode){
            case TANK:
                driveSubsystem.tankDrive(joystick.getRawAxis(0), joystick.getRawAxis(1));
                break;
            case ARCADE:
                driveSubsystem.arcadeDrive(-joystick.getRawAxis(1),-joystick.getRawAxis(2));
                break;
        }

    }

    @Override
    protected  boolean isFinished(){
        return false;
    }
}
