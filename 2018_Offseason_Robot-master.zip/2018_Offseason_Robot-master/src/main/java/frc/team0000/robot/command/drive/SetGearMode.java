package frc.team0000.robot.command.drive;
import edu.wpi.first.wpilibj.command.Command;
import frc.team0000.robot.command.*;
import frc.team0000.robot.Subsystem.drive.GearMode;
import frc.team0000.robot.Robot;


import java.util.logging.Logger;

public class SetGearMode extends Command{

    private static final Logger LOGGER = Logger.getLogger(SetGearMode.class.getName());

    private GearMode gearMode;

    public SetGearMode(GearMode gearMode){
        this.gearMode = gearMode;
    }
    //Runs the command

    @Override
    protected void initialize(){
      Robot.getDriveSubsystem().setGearMode(gearMode);
      LOGGER.info(String.format("Set the gear mode to %s.", gearMode));
    }

    @Override
    protected boolean isFinished(){
        return true;
    }
}
