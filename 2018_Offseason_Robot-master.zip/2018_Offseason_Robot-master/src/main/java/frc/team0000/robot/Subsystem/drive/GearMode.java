package frc.team0000.robot.Subsystem.drive;

public enum GearMode {HIGH,LOW}

