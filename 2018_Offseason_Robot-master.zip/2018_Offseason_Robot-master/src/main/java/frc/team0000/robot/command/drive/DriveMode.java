package frc.team0000.robot.command.drive;
//SImple enum for drive configs
public enum DriveMode {ARCADE, TANK}
