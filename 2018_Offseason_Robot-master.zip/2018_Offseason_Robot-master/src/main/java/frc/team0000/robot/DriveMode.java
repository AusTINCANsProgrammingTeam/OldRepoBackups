package frc.team0000.robot;
    //Simple enum for drive config.
    public enum DriveMode{ARCADE, TANK}

