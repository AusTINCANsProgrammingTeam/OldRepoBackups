package frc.team0000.robot.Subsystem.drive;

import edu.wpi.first.wpilibj.DoubleSolenoid;
import edu.wpi.first.wpilibj.GearTooth;
import edu.wpi.first.wpilibj.SpeedController;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;

import java.util.logging.Logger;

public class DriveSubsystem extends Subsystem{
    private static final Logger LOGGER = Logger.getLogger(DriveSubsystem.class.getName());

    private DifferentialDrive differentialDrive;
    private GearMode gearMode;
    private DoubleSolenoid gearboxSolenoid;

    //IThis intitializes the drive subsystem
    @Override
    protected void initDefaultCommand(){ }
    /**
     * This initializes the drive subsystem.
     * @param leftSpeedController the speedController on the left to be initialized.
     * @param rightSpeedController the speedController on the right to be initialized.
     * @param gearboxSolenoid Solenoid to be initialized.
     */

    public DriveSubsystem(SpeedController leftSpeedController, SpeedController rightSpeedController,DoubleSolenoid gearboxSolenoid){
        this.differentialDrive = new DifferentialDrive(leftSpeedController, rightSpeedController);
        differentialDrive.setSafetyEnabled(false);
        this.gearboxSolenoid = gearboxSolenoid;
        setGearMode(GearMode.LOW);
        LOGGER.info("Drive subsystem intialization complete!");
    }
    //set the speed for tank and arcade

    public void tankDrive(double leftSpeed, double rightSpeed){
        differentialDrive.tankDrive(leftSpeed, rightSpeed);
    }
    public void arcadeDrive(double velocity, double heading){
        differentialDrive.arcadeDrive(velocity, heading);
    }
    //return instance for gearMode

    public GearMode getGearMode(){
        return gearMode;
    }
    //sets the gear mode
    public void setGearMode(GearMode gearMode){
        this.gearMode = gearMode;
        updateGearMode();
    }

    //easy way to change gear mode after being set
    public void toggleGearMode(){
        switch(gearMode){
            case HIGH:
                gearMode = GearMode.LOW;
                break;
            case LOW:
                gearMode = GearMode.HIGH;
                break;
        }
        updateGearMode();
    }
    private void updateGearMode(){
        switch(gearMode){
            case HIGH:
                gearboxSolenoid.set(DoubleSolenoid.Value.kForward);
                break;
            case LOW:
                gearboxSolenoid.set(DoubleSolenoid.Value.kReverse);
                break;
        }
    }

}
