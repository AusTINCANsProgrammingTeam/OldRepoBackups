package frc.team2158.robot;
import com.ctre.CANTalon;
import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.can.TalonSRX;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.SpeedControllerGroup;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;

/*The following is the Drive subsystem, which handles all elemental drive functions, i.e. setting motor values
 */
public class Drive extends Subsystem{

    private WPI_TalonSRX l1;
    private WPI_TalonSRX l2;
    private WPI_TalonSRX l3;
    private WPI_TalonSRX r1;
    private WPI_TalonSRX r2;
    private WPI_TalonSRX r3;
    private SpeedControllerGroup mLeft;
    private SpeedControllerGroup mRight;
    private Encoder encLeft;
    private Encoder encRight;

    private double topSpeed;

    /**
     *
     * @param a1 Address for motor one, on left
     * @param a2 Address for motor two, on left
     * @param a3 Address for motor three, on left
     * @param a4 Address for motor four, on right
     * @param a5 Address for motor five, on right
     * @param a6 Address for motor six, on right
     */
    public Drive(int a1, int a2, int a3, int a4, int a5, int a6, boolean invl, boolean invr, int LA, int LB, int RA, int RB){
        l1 = new WPI_TalonSRX(a1);
        l2 = new WPI_TalonSRX(a2);
        l3 = new WPI_TalonSRX(a3);
        r1 = new WPI_TalonSRX(a4);
        r2 = new WPI_TalonSRX(a5);
        r3 = new WPI_TalonSRX(a6);
        mLeft = new SpeedControllerGroup(l1, l2, l3);
        mRight = new SpeedControllerGroup(r1, r2, r3);
        mLeft.setInverted(invl);
        mRight.setInverted(invr);
        encLeft = new Encoder(LA, LB);
        encRight = new Encoder(RA, RB);
    }

    public void initDefaultCommand(){
        setDefaultCommand(new Command_DriverInput("DefaultDrive"));
    }

    public void setLeft(double spd){
        mLeft.set(spd);
    }

    public void setRight(double spd){
        mRight.set(spd);
    }

    public boolean[] getInversion(){
        return new boolean[]{mLeft.getInverted(), mRight.getInverted()};
    }

    public void setInversion(boolean invl, boolean invr){
        mLeft.setInverted(invl);
        mRight.setInverted(invr);
    }

    public double[] getSpeed(){
        return new double[] {mLeft.get(), mRight.get()};
    }

    public void setAll(double spd){
        mLeft.set(spd);
        mRight.set(spd);
    }

    public void tank(double x, double y){
        mLeft.set(x);
        mRight.set(y);
    }

    public void arcade(double x, double y){
        this.setAll(x);
        if (y > 0){
            mRight.set(mRight.get()-Math.abs(y));
        }
        else if (y < 0){
            mLeft.set(mLeft.get()-Math.abs(y));
        }
    }
}
