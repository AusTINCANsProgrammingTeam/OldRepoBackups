package frc.team2158.robot;

import edu.wpi.first.wpilibj.Joystick;

public class Controller extends Joystick{
    public Controller(int port){
        super(port);
    }

    public double getAxisProcessed(int axis){
        return inputCurve(super.getRawAxis(axis));
    }

    private double inputCurve(double x){
        if (x <= 0) {
            return 0;
        }
        else if (x < .95) {
            return (Math.pow(25, x-1) - Math.pow(25, -1));
        }
        else {
            return 1;
        }
    }
}
