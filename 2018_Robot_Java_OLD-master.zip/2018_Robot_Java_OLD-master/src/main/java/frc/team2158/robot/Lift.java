package frc.team2158.robot;

import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.Solenoid;
import edu.wpi.first.wpilibj.command.Subsystem;

public class Lift extends Subsystem{
    private WPI_TalonSRX mLeft;
    private WPI_TalonSRX mRight;
    private Encoder encLift;
    private Solenoid brake;

    public Lift(int a1, int a2, int solenoidPort, int encA, int encB){
        mLeft = new WPI_TalonSRX(a1);
        mRight = new WPI_TalonSRX(a2);
        mRight.setInverted(true);
        brake = new Solenoid(solenoidPort);
        encLift = new Encoder(encA, encB);
    }

    public void initDefaultCommand(){
        setDefaultCommand(new Command_MoveLift("Stop", this.getLoc()));
    }

    public double getLoc(){
        return encLift.get();
    }

    public boolean[] getInversions(){
        return new boolean[] {mLeft.getInverted(), mRight.getInverted()};
    }

    public void setMotors(double spd){
        mLeft.set(spd);
        mRight.set(spd);
    }

    public void extend(){
        if(!brake.get())
            brake.set(true);
    }

    public void retract(){
        if(brake.get())
            brake.set(false);
    }

    public void toggle(){
        brake.set(!brake.get());
    }

    public boolean getState(){
        return brake.get();
    }
}
