package frc.team2158.robot;

import edu.wpi.first.wpilibj.command.Command;

public class Command_DriverInput extends Command {

    public Command_DriverInput(String name){
        super(name);
        this.setRunWhenDisabled(false);
        requires(Robot.drive);
        this.setInterruptible(false);
    }

    public void execute(){
        Robot.drive.arcade(Robot.oi.getStick().getAxisProcessed(0),
                           Robot.oi.getStick().getAxisProcessed(3));
    }

    public void cancel(){
        super.cancel();
    }

    public boolean isFinished(){
        return false;
    }

    public void end(){
        Robot.drive.setAll(0);
    }

    public void interrupted(){
        super.interrupted(); //Important because Command calls end here
        if(this.isCanceled()){
            System.err.println("For some fucking reason, command " + this.getName() + " has been cancelled.");
        }
        else
            System.err.println("Command " + this.getName() + " has been interrupted.");
    }
}
