package frc.team2158.robot;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.command.Scheduler;

public class Robot extends TimedRobot {
    //OI
    public static final OI oi = new OI();
    //Subsystems
    public static final Drive drive = new Drive(
            RobotMap.LEFT_MOTOR_1, RobotMap.LEFT_MOTOR_2, RobotMap.LEFT_MOTOR_3, RobotMap.RIGHT_MOTOR_1,
            RobotMap.RIGHT_MOTOR_2, RobotMap.RIGHT_MOTOR_3, RobotMap.INV_LEFT, RobotMap.INV_RIGHT,
            RobotMap.ENCODER_LEFT_A, RobotMap.ENCODER_LEFT_B, RobotMap.ENCODER_RIGHT_A, RobotMap.ENCODER_RIGHT_B);

    public static final Lift lift =  new Lift(RobotMap.LEFT_LIFT_MOTOR, RobotMap.RIGHT_LIFT_MOTOR,
            RobotMap.BRAKE_PORT, RobotMap.LIFT_ENCODER_A, RobotMap.LIFT_ENCODER_B);

    public static final Intake intake = new Intake(RobotMap.INTAKE_MOTOR_LEFT, RobotMap.INTAKE_MOTOR_LEFT);

    @Override
    public void robotInit() { }

    @Override
    public void disabledInit() { }

    @Override
    public void autonomousInit() { }

    @Override
    public void teleopInit() { }

    @Override
    public void disabledPeriodic() { }
    
    @Override
    public void autonomousPeriodic() { }

    @Override
    public void teleopPeriodic() {
        drive.getDefaultCommand().start(); //Shooting myself if this doesn't make the robot drive
    }
}