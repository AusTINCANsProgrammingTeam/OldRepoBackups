package frc.team2158.robot;

import edu.wpi.first.wpilibj.buttons.JoystickButton;

public class OI {

    private Controller stick = new Controller(RobotMap.STICKPORT);

    //Bind buttons to commands in constructor

    public OI(){
        //Create Buttons and bind to button#
        JoystickButton intake = new JoystickButton(stick, RobotMap.COMMAND_INTAKE_BUTTON);
        JoystickButton outtake = new JoystickButton(stick, RobotMap.COMMAND_OUTTAKE_BUTTON);

        //Binding commands
        intake.whileHeld(new Command_RunIntake("Intake", 1));
        outtake.whileHeld(new Command_RunIntake("Outtake", -1));
    }

    public Controller getStick(){
        return stick;
    }
}
