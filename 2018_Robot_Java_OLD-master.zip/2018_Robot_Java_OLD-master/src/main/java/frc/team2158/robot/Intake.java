package frc.team2158.robot;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Spark;
import edu.wpi.first.wpilibj.command.Subsystem;

public class Intake extends Subsystem {
    private Spark mLeft;
    private Spark mRight;

    public Intake(int portmLeft, int portmRight) {
        mLeft = new Spark(portmLeft);
        mRight = new Spark(portmRight);
    }

    public void initDefaultCommand(){
        setDefaultCommand(new Command_RunIntake("Intake", 0));
    }

    public void spin(int dir){
        mLeft.set(dir);
        mRight.set(-dir);
    }
}
