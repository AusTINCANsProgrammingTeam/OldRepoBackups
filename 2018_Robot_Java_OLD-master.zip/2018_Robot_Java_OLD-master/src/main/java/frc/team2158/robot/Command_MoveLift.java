package frc.team2158.robot;

import edu.wpi.first.wpilibj.command.Command;

public class Command_MoveLift extends Command{
    /*
    Raises or lowers the lift to the specified height
     */
    private double setpoint;

    public Command_MoveLift(String name, double setpoint) {
        super(name);
        this.setRunWhenDisabled(false);
        requires(Robot.lift);
        this.setpoint = setpoint;
    }

    public void execute(){ //needs motion profile
        if(Robot.lift.getLoc() < setpoint){
            Robot.lift.setMotors(1);
        }
        else if (Robot.lift.getLoc() > setpoint){
            Robot.lift.setMotors(-1);
        }
    }

    public void cancel(){
        Robot.lift.setMotors(0);
    }


    public boolean isFinished(){
        if (Robot.lift.getLoc() == setpoint){
            Robot.lift.setMotors(0);
            return true;
        }
        else
            return false;
    }

    public void interrupted(){
        if(this.isCanceled()){
            System.err.println("For some fucking reason, command " + this.getName() + " has been cancelled.");
        }
        else
            System.out.println("Command " + this.getName() + " has been interrupted.");
    }
}
