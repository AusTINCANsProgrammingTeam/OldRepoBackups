package frc.team2158.robot;

public class RobotMap {
    //Addresses and inversions for TalonSRXs on Drivebase
    public static final int LEFT_MOTOR_1 = 2;
    public static final int LEFT_MOTOR_2 = 3;
    public static final int LEFT_MOTOR_3 = 4;
    public static final int RIGHT_MOTOR_1 = 5;
    public static final int RIGHT_MOTOR_2 = 6;
    public static final int RIGHT_MOTOR_3 = 7;
    public static final boolean INV_LEFT = false;
    public static final boolean INV_RIGHT = true;
    //Ports for encoders on drive
    public static final int ENCODER_LEFT_A = 0;
    public static final int ENCODER_LEFT_B = 1;
    public static final int ENCODER_RIGHT_A = 2;
    public static final int ENCODER_RIGHT_B = 3;

    //Addresses and inversions for TalonSRXs on lift
    public static final int LEFT_LIFT_MOTOR = 14;
    public static final int RIGHT_LIFT_MOTOR = 16;
    public static final boolean LIFT_INV_LEFT = false;
    public static final boolean LIFT_INV_RIGHT = true;
    //Ports for encoder on Lift
    public static final int LIFT_ENCODER_A = 98;
    public static final int LIFT_ENCODER_B = 99;
    //Ports for solenoid on lift
    public static final int BRAKE_PORT = 0;

    //Addresses and inversions for Sparks on intake
    public static final int INTAKE_MOTOR_LEFT = 0;
    public static final int INTAKE_MOTOR_RIGHT = 1;

    //Joystick USB port and stick mappings
    public static final int STICKPORT = 0;
    public static final int LEFT_DRIVE_AXIS = 0; //left stick on joystick
    public static final int RIGHT_DRIVE_AXIS = 3; //right stick on joystick
    public static final int COMMAND_DRIVERINPUT_BUTTON = 0;
    public static final int COMMAND_MOVELIFTUP_BUTTON = 1;
    public static final int COMMAND_MOVELIFTDOWN_BUTTON = 2;
    public static final int COMMAND_INTAKE_BUTTON = 3;
    public static final int COMMAND_OUTTAKE_BUTTON = 4;
}
