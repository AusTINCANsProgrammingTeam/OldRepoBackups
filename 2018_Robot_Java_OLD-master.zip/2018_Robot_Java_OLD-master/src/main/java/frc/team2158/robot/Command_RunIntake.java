package frc.team2158.robot;

import edu.wpi.first.wpilibj.command.Command;

public class Command_RunIntake extends Command {

    int dir;

    public Command_RunIntake(String name, int dir){
        super(name);
        requires(Robot.intake);
        this.dir = dir;
    }

    public void interrupted(){
        if(this.isCanceled()){
            System.err.println("For some fucking reason, command " + this.getName() + " has been cancelled.");
        }
        else
            System.out.println("Command " + this.getName() + " has been interrupted.");
    }

    public void execute(){
        Robot.intake.spin(dir);
    }

    public void end(){
        Robot.intake.spin(0);
    }

    public boolean isFinished(){
        return false;
    }
}
