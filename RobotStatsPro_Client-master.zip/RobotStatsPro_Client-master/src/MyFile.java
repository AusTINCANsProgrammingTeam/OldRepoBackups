import java.util.Formatter;

public class MyFile {
	private Formatter f;
	private String fileName;
	public MyFile(String fileName, Wandow w){
		this.fileName = fileName;
	}
	public void createFile(){
		try{
			f = new Formatter(fileName);
			System.out.println(String.format("%s created successfully.", fileName));
		}
		catch(Exception e){
			System.out.println("Error while creating file.");
		}
	}
	public void writeString(String s){
		f.format("%s\n", s);
	}
	public void closeFile(){
		f.close();
	}
}
