import javax.swing.JFrame;
import javax.swing.JComponent;
import java.awt.FlowLayout;
import java.util.*;
//All input panes return STRINGS
public class Wandow extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 244495746874399928L;
	public Wandow(){
		super("RobotStatsProClient_AlphaV_0.1");
		setLayout(primary);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//create a file and write to it
		MyFile f = new MyFile("Untitled 1.txt", this);
		f.createFile();
		FinalizeInformationButton fin = new FinalizeInformationButton("Finalize Data", this, f);
		addCompPrim(fin);
		InfoPane i = new InfoPane("Team Tag: ");
		addCompPrim(i);
		InputPane p = new InputPane(4, "teamTag");
		addCompPrim(p);
		addCompInfo(p);
		InputButton lowgoals = new InputButton("Low Goals", "lowGoalsScored_TO");
		InputButton highgoals = new InputButton("High Goals", "highGoalsScored_TO");
		InputButton hgoala = new InputButton("High Goal Attempts", "highGoalsAttempted_TO");
		InputButton lgoala = new InputButton("Low Goal Attempts", "lowGoalsAttempted_TO");
		addCompPrim(lowgoals); addCompPrim(highgoals); addCompPrim(hgoala); addCompPrim(lgoala);
		addCompInfo(lowgoals); addCompInfo(highgoals); addCompInfo(hgoala); addCompInfo(lgoala);
		InfoPane aS = new InfoPane("Alliance Score: "); //alliance score
		InputPane aSI = new InputPane(4, "collectiveAllianceScore"); //input alliance score
		addCompPrim(aS); addCompPrim(aSI);
		ChangeUIButton changeFrame = new ChangeUIButton("To Autonomous", "To TeleOP", this);
		addCompPrim(changeFrame);
		addCompAuto(changeFrame);
		primListToFrame();
		setSize(500, 500);
		setVisible(true);
	}
	FlowLayout primary = new FlowLayout();
	private ArrayList<JComponent> primaryList = new ArrayList<JComponent>();
	private ArrayList<JComponent> autoList = new ArrayList<JComponent>();
	private ArrayList<JComponent> infoList = new ArrayList<JComponent>();
	//private ArrayList<String> infoList = new ArrayList<String>();//stores information from screen, not sure if needed
	private boolean x = true; //toggle for changeUI()
	
	public void changeUI(){
		if (x){
			autoListToFrame();
			x = !x;
		}
		else{
			primListToFrame();
			x = !x;
		}
	}
	public void addCompPrim(JComponent c){
		primaryList.add(c);
	}
	public void addCompAuto(JComponent c){
		autoList.add(c);
	}
	public void addCompInfo(JComponent c){
		infoList.add(c);
	}
	public void primListToFrame(){
		clearFrame();
		for(int i=0; i<primaryList.size(); i++){
			add(primaryList.get(i));
		}
		repaint();
	}
	public void autoListToFrame(){
		clearFrame();
		for(int i=0; i<autoList.size(); i++){
			add(autoList.get(i));
		}
		repaint();
	}
	public void clearFrame(){
		getContentPane().removeAll();
		repaint();
	}
	public boolean getThisX(){
		return x;
	}
	public void writeToFile(MyFile f){
		for(int i=0; i<infoList.size(); i++){
			f.writeString(infoList.get(i).toString());
		}
	}
}
