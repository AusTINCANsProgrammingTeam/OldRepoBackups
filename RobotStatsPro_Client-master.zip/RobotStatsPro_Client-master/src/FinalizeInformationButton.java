import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class FinalizeInformationButton extends JButton {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8656565656020188126L;
	public FinalizeInformationButton(String title, Wandow w, MyFile f){
		super(title);
		final class Handler implements ActionListener{
			public void actionPerformed(ActionEvent event){
				w.writeToFile(f);
				f.closeFile();
				w.clearFrame();
				w.add(new InfoPane("Data written to file. Form Complete."));
			}
		}
		Handler h = new Handler();
		addActionListener(h);
	}
}
