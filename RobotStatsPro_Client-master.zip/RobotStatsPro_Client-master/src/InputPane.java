import javax.swing.JTextField;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;

public class InputPane extends JTextField {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4035331275581624191L;
	public InputPane(int size, String dataContained){
		super(size);
		this.dataContained = dataContained;
		Handler h = new Handler();
		getDocument().addDocumentListener(h);
	}
	String s;
	String dataContained;
	private class Handler implements DocumentListener{
		@Override
		public void changedUpdate(DocumentEvent arg0) {
			try{
				s = getText();
			//System.out.println(s);
			}
			catch(Exception e){
				System.out.println("Strange error??");
			}
		}

		@Override
		public void insertUpdate(DocumentEvent arg0) {
			try{
				s = getText();
			//System.out.println(s);
			}
			catch(Exception e){
				System.out.println("Strange error??");
			}
		}

		@Override
		public void removeUpdate(DocumentEvent arg0) {
			try{
				s = getText();
			//System.out.println(s);
			}
			catch(Exception e){
				System.out.println("Strange error??");
			}
		}
	}
	public String toString(){
		String s = String.format(dataContained + "=%s", getText());
		return s; 
	}
}
