import javax.swing.JTextField;

public class InfoPane extends JTextField {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7525525617746014136L;

	public InfoPane(String msg){
		super(msg);
		setEditable(false);
	}
}
