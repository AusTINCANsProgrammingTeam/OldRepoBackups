import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;

public class ChangeUIButton extends JButton {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4837811987892714173L;

	public ChangeUIButton(String title, String title2, Wandow w){
		super(title);
		final class Handler implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				changeWandow(w);
				if(!w.getThisX()){
					setText(title2);
				}
				else{
					setText(title);
				}
			}
			public void changeWandow(Wandow w){
				w.changeUI();
			}	
		}
		Handler h = new Handler();
		addActionListener(h);
	}
}
