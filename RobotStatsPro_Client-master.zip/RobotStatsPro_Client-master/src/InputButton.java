import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
//Buttons for counting single instances
public class InputButton extends JButton {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5576723143412238683L;
	public InputButton(String title, String dataContained){
		super(title);
		this.dataContained = dataContained;
		Handler h = new Handler();
		addActionListener(h);
	}
	private String dataContained;
	private int c;
	private class Handler implements ActionListener{
		public void actionPerformed(ActionEvent event){
			try{
				c+=1;
				//System.out.println(c);
			}
			catch(Exception e){
				System.out.println("Other weird error??");
			}
		}
	}
	public String toString(){
		String s = String.format(dataContained + "=%s", c);
		return s;
	}
}
